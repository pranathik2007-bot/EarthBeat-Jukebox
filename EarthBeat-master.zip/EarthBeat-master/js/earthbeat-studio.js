/* ============================================================================
   EARTHBEAT STUDIO — Master Interactive & Sonification Engine
   File: js/earthbeat-studio.js
   Architecture:
     1. Mobile navigation & header scroll dynamics (from Waveform UI)
     2. Complete NASA Climate CSV Loading & Parsing (from script.js source of truth)
     3. Exact Web Audio API Data Sonification Engine (from script.js source of truth)
     4. Synchronized NASA Climate Spiral Video & Dynamic VU Meter
     5. Real-Time Animated Waveform Equalizer Integration
   ========================================================================== */

(function () {
  "use strict";

  // ==========================================================================
  // SECTION 1: STUDIO NAVIGATION & UI BEHAVIORS
  // ==========================================================================

  function initStudioNav() {
    var toggle = document.getElementById("navToggle");
    var panel = document.getElementById("navPanel");
    if (!toggle || !panel) return;

    function closeNav() {
      panel.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    }

    toggle.addEventListener("click", function () {
      var isOpen = panel.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    panel.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", closeNav);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeNav();
    });

    window.addEventListener("resize", function () {
      if (window.innerWidth > 900) closeNav();
    });
  }

  function initHeaderScroll() {
    var header = document.querySelector(".site-header");
    if (!header) return;
    var onScroll = function () {
      header.classList.toggle("scrolled", window.scrollY > 12);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  function initExploreButton() {
    var exploreBtn = document.getElementById("exploreBtn");
    var message = document.getElementById("message");
    if (exploreBtn && message) {
      exploreBtn.addEventListener("click", function () {
        message.textContent = "Great! Let's explore our changing planet!";
        var exploreSection = document.getElementById("explore") || document.getElementById("studio-rack");
        if (exploreSection) {
          exploreSection.scrollIntoView({ behavior: "smooth" });
        }
      });
    }
  }

  // ==========================================================================
  // SECTION 2: NASA CLIMATE DATA PROCESSING LOGIC
  // Preserves 100% of the CSV loading, validation, and reversal logic from script.js
  // ==========================================================================

  var temperatureHistory = [];

  async function loadNASAData() {
    var yearDisplay = document.getElementById("tempYear");
    var valueDisplay = document.getElementById("tempValue");
    var statusDisplay = document.getElementById("dataStatus");

    try {
      var response = await fetch("GLB.Ts+dSST.csv");

      if (!response.ok) {
        throw new Error("Could not load the NASA CSV file.");
      }

      var csvText = await response.text();
      var rows = csvText.replace(/^\uFEFF/, "").split(/\r?\n/);

      // Find the CSV heading row
      var headerIndex = rows.findIndex(function (row) {
        return row.trim().startsWith("Year,");
      });

      if (headerIndex === -1) {
        throw new Error("Could not find the CSV headings.");
      }

      var headers = rows[headerIndex].split(",");
      var months = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
      ];

      var latestData = null;
      temperatureHistory = []; // Reset array

      // Backward iteration from newest to oldest row, Dec to Jan
      for (var i = rows.length - 1; i > headerIndex; i--) {
        var columns = rows[i].split(",");
        var year = Number(columns[0]);

        if (!Number.isInteger(year) || year < 1880) {
          continue;
        }

        for (var j = months.length - 1; j >= 0; j--) {
          var monthIndex = headers.indexOf(months[j]);

          if (monthIndex === -1) continue;

          var value = Number(columns[monthIndex]);

          if (columns[monthIndex]?.trim() !== "" && Number.isFinite(value)) {
            latestData = {
              year: year,
              month: months[j],
              value: value
            };
            temperatureHistory.push({
              year: year,
              month: months[j],
              value: value
            });
          }
        }
      }

      // Reverse so data is in chronological order: 1880 to present
      temperatureHistory.reverse();

      console.log("First 5 records:", temperatureHistory.slice(0, 5));
      console.log("Last 5 records:", temperatureHistory.slice(-5));

      latestData = temperatureHistory[temperatureHistory.length - 1];

      if (!latestData) {
        throw new Error("No valid temperature data was found.");
      }

      // Display NASA data on the website
      if (yearDisplay) {
        yearDisplay.textContent =
          "Latest available data: " +
          latestData.month + " " + latestData.year;
      }

      if (valueDisplay) {
        valueDisplay.textContent =
          "Temperature anomaly: " +
          (latestData.value > 0 ? "+" : "") +
          latestData.value.toFixed(2) + " °C";
      }

      if (statusDisplay) {
        statusDisplay.textContent =
          "NASA temperature data loaded successfully!";
      }

      // Initialize progress bar max if element exists
      var soundProgress = document.getElementById("soundProgress");
      if (soundProgress) {
        soundProgress.max = temperatureHistory.length;
      }

      var playbackProgress = document.getElementById("playbackProgress");
      if (playbackProgress) {
        playbackProgress.textContent = "0 / " + temperatureHistory.length + " records played";
      }

      console.log("Latest NASA temperature data:", latestData);

    } catch (error) {
      console.error(error);

      if (statusDisplay) {
        statusDisplay.textContent =
          "Unable to load NASA data. Please check the CSV file.";
      }
    }
  }

  // ==========================================================================
  // SECTION 3: WEB AUDIO API SONIFICATION ENGINE & PLAYBACK CONTROLS
  // Preserves 100% of the Web Audio formula, envelope, and mode delays from script.js
  // ==========================================================================

  var audioContext = null;
  var oscillator = null;
  var gainNode = null;
  var soundTimer = null;
  var currentSoundIndex = 0;
  var isPlaying = false;

  // Waveform equalizer DOM helper (connects audio state to visual bars)
  function setWaveformPlaying(active) {
    isPlaying = active;
    var waveforms = document.querySelectorAll(".studio-waveform, #heroWave");
    waveforms.forEach(function (wave) {
      wave.classList.toggle("playing", active);
    });

    var playBtns = document.querySelectorAll("#playBtn, #heroPlay");
    playBtns.forEach(function (btn) {
      btn.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function stopEarthBeat() {
    if (soundTimer !== null) {
      clearTimeout(soundTimer);
      soundTimer = null;
    }

    if (oscillator) {
      try {
        oscillator.stop();
      } catch (error) {
        // Sound may already have stopped
      }
      oscillator = null;
    }

    currentSoundIndex = 0;
    setWaveformPlaying(false);
  }

  function playEarthBeat() {
    if (!temperatureHistory || temperatureHistory.length === 0) {
      alert("NASA temperature data is not available yet.");
      return;
    }

    stopEarthBeat();

    if (!audioContext) {
      audioContext = new (
        window.AudioContext ||
        window.webkitAudioContext
      )();
    }

    audioContext.resume().then(function () {
      setWaveformPlaying(true);

      var playingDate = document.getElementById("playingDate");
      var playbackProgress = document.getElementById("playbackProgress");
      var soundProgress = document.getElementById("soundProgress");
      var playbackStatus = document.getElementById("playbackStatus");
      var visualDate = document.getElementById("visualDate");
      var visualTemp = document.getElementById("visualTemp");
      var temperatureBar = document.getElementById("temperatureBar");
      var temperatureLevel = document.getElementById("temperatureLevel");
      var liveFrequency = document.getElementById("liveFrequency");

      function playNextNote() {
        if (currentSoundIndex >= temperatureHistory.length) {
          stopEarthBeat();

          var climateVideo = document.getElementById("climateVideo");
          if (climateVideo) {
            climateVideo.pause();
            climateVideo.currentTime = 0;
          }

          if (playingDate) playingDate.textContent = "EarthBeat completed!";

          if (playbackProgress) {
            playbackProgress.textContent =
              temperatureHistory.length + " / " +
              temperatureHistory.length + " records played";
          }

          if (soundProgress) {
            soundProgress.value = soundProgress.max;
          }

          if (playbackStatus) {
            playbackStatus.textContent =
              "You have listened to the complete NASA temperature dataset!";
          }

          return;
        }

        var data = temperatureHistory[currentSoundIndex];
        var playMode = document.getElementById("playMode");
        var isDemoMode = playMode && playMode.value === "demo";

        // Update playback information
        if (playingDate) {
          playingDate.textContent = "Now playing: " + data.month + " " + data.year;
        }

        if (visualDate) {
          visualDate.textContent = "Climate data: " + data.month + " " + data.year;
        }

        if (visualTemp) {
          visualTemp.textContent =
            "Temperature anomaly: " +
            (data.value > 0 ? "+" : "") +
            data.value.toFixed(2) + " °C";
        }

        // Update dynamic temperature indicator
        if (temperatureBar && temperatureLevel) {
          var barWidth = Math.min(
            Math.abs(data.value) / 1.5 * 100,
            100
          );
          temperatureBar.style.width = Math.max(barWidth, 5) + "%";

          if (data.value < -0.1) {
            temperatureBar.style.background = "#3986D8";
            temperatureLevel.textContent = "Below baseline";
          } else if (data.value > 0.1) {
            temperatureBar.style.background = "#E66B45";
            temperatureLevel.textContent = "Above baseline";
          } else {
            temperatureBar.style.background = "#D6B64A";
            temperatureLevel.textContent = "Near baseline";
          }
        }

        if (playbackProgress) {
          playbackProgress.textContent =
            (currentSoundIndex + 1) + " / " +
            temperatureHistory.length + " records played";
        }

        if (soundProgress) {
          soundProgress.max = temperatureHistory.length;
          soundProgress.value = currentSoundIndex + 1;
        }

        if (playbackStatus) {
          playbackStatus.textContent = "EarthBeat is playing...";
        }

        // Exact temperature anomaly to sound pitch mapping
        var frequency = Math.max(
          220,
          Math.min(660, 440 + data.value * 100)
        );

        if (liveFrequency) {
          liveFrequency.textContent = Math.round(frequency) + " Hz";
        }

        oscillator = audioContext.createOscillator();
        gainNode = audioContext.createGain();

        oscillator.type = "sine";
        oscillator.frequency.value = frequency;

        // Exact note duration according to mode
        var noteDuration = isDemoMode ? 0.18 : 0.35;

        // Envelope: 0.08 initial attack, decay to 0 at noteDuration
        gainNode.gain.setValueAtTime(0.08, audioContext.currentTime);
        gainNode.gain.setValueAtTime(0, audioContext.currentTime + noteDuration);

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.start();
        oscillator.stop(audioContext.currentTime + noteDuration);

        currentSoundIndex++;

        // Exact playback interval delay according to mode
        var playbackDelay = isDemoMode ? 250 : 500;

        soundTimer = setTimeout(playNextNote, playbackDelay);
      }

      playNextNote();

    }).catch(function (error) {
      console.error("Audio error:", error);
    });
  }

  // ==========================================================================
  // SECTION 4: CONTROLLER BINDINGS & VIDEO SYNCHRONIZATION
  // ==========================================================================

  function bindStudioControls() {
    var playBtn = document.getElementById("playBtn");
    var stopBtn = document.getElementById("stopBtn");
    var heroPlay = document.getElementById("heroPlay");
    var climateVideo = document.getElementById("climateVideo");

    // Primary Play Button
    if (playBtn) {
      playBtn.addEventListener("click", function () {
        playEarthBeat();

        if (climateVideo) {
          climateVideo.muted = true;
          climateVideo.play().catch(function (error) {
            console.log("Video playback error:", error);
          });
        }
      });
    }

    // Hero Play Toggle Button (synchronized with main engine)
    if (heroPlay) {
      heroPlay.addEventListener("click", function () {
        if (isPlaying) {
          stopEarthBeat();
          if (climateVideo) {
            climateVideo.pause();
            climateVideo.currentTime = 0;
          }
        } else {
          playEarthBeat();
          if (climateVideo) {
            climateVideo.muted = true;
            climateVideo.play().catch(function (error) {
              console.log("Video playback error:", error);
            });
          }
        }
      });
    }

    // Primary Stop Button
    if (stopBtn) {
      stopBtn.addEventListener("click", function () {
        stopEarthBeat();

        if (climateVideo) {
          climateVideo.pause();
          climateVideo.currentTime = 0;
        }
      });
    }

    // Stop playback if the climate video ends
    if (climateVideo) {
      climateVideo.addEventListener("ended", function () {
        stopEarthBeat();
      });
    }
  }

  // ==========================================================================
  // SECTION 5: INITIALIZATION LIFECYCLE
  // ==========================================================================

  function bootStudio() {
    initStudioNav();
    initHeaderScroll();
    initExploreButton();
    bindStudioControls();
    loadNASAData();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bootStudio);
  } else {
    bootStudio();
  }

})();
