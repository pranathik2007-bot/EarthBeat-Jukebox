/* ============================================================================
   Waveform — template behaviour. Vanilla JS, zero libraries. Each feature is
   a guard-claused init so a missing element never throws.
   ========================================================================== */
(function () {
  "use strict";

  /* -------------------------------------------------- mobile nav */
  function initNav() {
    var toggle = document.getElementById("navToggle");
    var panel = document.getElementById("navPanel");
    if (!toggle || !panel) return;

    function close() {
      panel.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    }

    toggle.addEventListener("click", function () {
      var open = panel.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });

    // close after tapping a link (mobile)
    panel.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", close);
    });

    // close on Escape / resize back to desktop
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
    window.addEventListener("resize", function () {
      if (window.innerWidth > 900) close();
    });
  }

  /* -------------------------------------------------- header shadow on scroll */
  function initHeader() {
    var header = document.querySelector(".site-header");
    if (!header) return;
    var onScroll = function () {
      header.classList.toggle("scrolled", window.scrollY > 12);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* -------------------------------------------------- hero waveform player */
  function initHeroPlayer() {
    var btn = document.getElementById("heroPlay");
    var wave = document.getElementById("heroWave");
    if (!btn || !wave) return;

    btn.addEventListener("click", function () {
      var playing = wave.classList.toggle("playing");
      btn.setAttribute("aria-pressed", playing ? "true" : "false");
    });
  }

  /* -------------------------------------------------- mix list play toggles */
  function initMixes() {
    var list = document.getElementById("mixList");
    if (!list) return;
    var rows = Array.prototype.slice.call(list.querySelectorAll("[data-mix]"));

    rows.forEach(function (row) {
      var btn = row.querySelector(".mix-play");
      if (!btn) return;

      btn.addEventListener("click", function () {
        var isActive = row.classList.contains("active");

        // reset everything
        rows.forEach(function (r) {
          r.classList.remove("active");
          var b = r.querySelector(".mix-play");
          if (b) b.setAttribute("aria-pressed", "false");
        });

        // toggle the clicked one (pause if it was already playing)
        if (!isActive) {
          row.classList.add("active");
          btn.setAttribute("aria-pressed", "true");
        }
      });
    });
  }

  /* -------------------------------------------------- booking form */
  function initBookingForm() {
    var form = document.getElementById("bookingForm");
    if (!form) return;
    var msg = document.getElementById("bookingMsg");

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      if (msg) {
        msg.style.display = "block";
        msg.focus && msg.focus();
      }
      form.reset();
    });
  }

  /* -------------------------------------------------- scroll reveal */
  function initReveal() {
    var items = document.querySelectorAll(".reveal");
    if (!items.length) return;

    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || !("IntersectionObserver" in window)) {
      items.forEach(function (el) { el.classList.add("in"); });
      return;
    }

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });

    items.forEach(function (el) { io.observe(el); });
  }

  /* -------------------------------------------------- boot */
  function boot() {
    initNav();
    initHeader();
    initHeroPlayer();
    initMixes();
    initBookingForm();
    initReveal();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
