// EARTHBEAT - Main JavaScript

// 1. Explore Earth button
const exploreBtn = document.getElementById("exploreBtn");
const message = document.getElementById("message");

if (exploreBtn && message) {
    exploreBtn.addEventListener("click", function () {
        message.textContent =
            "Great! Let's explore our changing planet!";
    });
}

// 2. NASA temperature data
let temperatureHistory = [];
async function loadNASAData() {
    const yearDisplay = document.getElementById("tempYear");
    const valueDisplay = document.getElementById("tempValue");
    const statusDisplay = document.getElementById("dataStatus");

    try {
        const response = await fetch("GLB.Ts+dSST.csv");

        if (!response.ok) {
            throw new Error("Could not load the NASA CSV file.");
        }

        const csvText = await response.text();
        const rows = csvText.replace(/^\uFEFF/, "").split(/\r?\n/);

        // Find the CSV heading row
        const headerIndex = rows.findIndex(row =>
            row.trim().startsWith("Year,")
        );

        if (headerIndex === -1) {
            throw new Error("Could not find the CSV headings.");
        }

        const headers = rows[headerIndex].split(",");
        const months = [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];

        // Find the latest available temperature value
        
        let latestData = null;

        for (let i = rows.length - 1; i > headerIndex; i--) {
            const columns = rows[i].split(",");
            const year = Number(columns[0]);

            if (!Number.isInteger(year) || year < 1880) {
                continue;
            }

            for (let j = months.length - 1; j >= 0; j--) {
                const monthIndex = headers.indexOf(months[j]);

                if (monthIndex === -1) continue;

                const value = Number(columns[monthIndex]);

                if (columns[monthIndex]?.trim() !== "" &&
                    Number.isFinite(value)) {
                    latestData = {
                        year: year,
                        month: months[j],
                        value: value
                    };
                    temperatureHistory.push({
                        year:year,
                        month:months[j],
                        value:value
                    });
                    
                }
            }

            
        }
        temperatureHistory.reverse();
      //  console.log("Total temperature records:", temperatureHistory.length);
console.log("First 5 records:", temperatureHistory.slice(0, 5));
console.log("Last 5 records:", temperatureHistory.slice(-5));

latestData = temperatureHistory[temperatureHistory.length - 1];

        if (!latestData) {
            throw new Error("No valid temperature data was found.");
        }

        // Display NASA data on the website
        yearDisplay.textContent =
            "Latest available data: " +
            latestData.month + " " + latestData.year;

        valueDisplay.textContent =
            "Temperature anomaly: " +
            (latestData.value > 0 ? "+" : "") +
            latestData.value.toFixed(2) + " °C";

        statusDisplay.textContent =
            "NASA temperature data loaded successfully!";

        console.log("Latest NASA temperature data:", latestData);

    } catch (error) {
        console.error(error);

        if (statusDisplay) {
            statusDisplay.textContent =
                "Unable to load NASA data. Please check the CSV file.";
        }
    }
}

// 3. Start loading NASA data
loadNASAData();// 4. EARTHBEAT SOUND SYSTEM

let audioContext;
let oscillator;
let gainNode;
let soundTimer = null;
let currentSoundIndex = 0;


 // EARTHBEAT - NASA DATA SONIFICATION

// Play sound button
const playBtn = document.getElementById("playBtn");
const stopBtn = document.getElementById("stopBtn");
// Playback display elements
const playingDate = document.getElementById("playingDate");
const playbackProgress = document.getElementById("playbackProgress");
const soundProgress = document.getElementById("soundProgress");
const playbackStatus = document.getElementById("playbackStatus");

function stopEarthBeat() {
    if (soundTimer !== null) {
        clearTimeout(soundTimer);
        soundTimer = null;
    }

    if (oscillator) {
        try {
            oscillator.stop();
        } catch (error) {
            // Sound may already have stopped
        }

        oscillator = null;
    }

    currentSoundIndex = 0;

    
}
function playEarthBeat() {


    ;    if (!temperatureHistory || temperatureHistory.length === 0) {
        alert("NASA temperature data is not available yet.");
        return;
    }

    stopEarthBeat();

    if (!audioContext) {
        audioContext = new (
            window.AudioContext ||
            window.webkitAudioContext
        )();
    }

    audioContext.resume().then(() => {

        function playNextNote() {

            if (currentSoundIndex >= temperatureHistory.length) {

                stopEarthBeat();

                const climateVideo = document.getElementById("climateVideo");

if (climateVideo) {
    climateVideo.pause();
    climateVideo.currentTime = 0;
}

                playingDate.textContent = "EarthBeat completed!";

                playbackProgress.textContent =
                    temperatureHistory.length + " / " +
                    temperatureHistory.length + " records played";

                soundProgress.value = soundProgress.max;

                playbackStatus.textContent =
                    "You have listened to the complete NASA temperature dataset!";

                return;
            }

            const data = temperatureHistory[currentSoundIndex];

            const playMode = document.getElementById("playMode");

            // Update playback information
            playingDate.textContent =
                "Now playing: " + data.month + " " + data.year;
                document.getElementById("visualDate").textContent =
    "Climate data: " + data.month + " " + data.year;document.getElementById("visualTemp").textContent =
    "Temperature anomaly: " +
    (data.value > 0 ? "+" : "") +
    data.value.toFixed(2) + " °C";

    // Update temperature indicator
const temperatureBar = document.getElementById("temperatureBar");
const temperatureLevel = document.getElementById("temperatureLevel");

const barWidth = Math.min(
    Math.abs(data.value) / 1.5 * 100,
    100
);

temperatureBar.style.width = Math.max(barWidth, 5) + "%";

if (data.value < -0.1) {
    temperatureBar.style.background = "#3986D8";
    temperatureLevel.textContent = "Below baseline";
}
else if (data.value > 0.1) {
    temperatureBar.style.background = "#E66B45";
    temperatureLevel.textContent = "Above baseline";
}
else {
    temperatureBar.style.background = "#D6B64A";
    temperatureLevel.textContent = "Near baseline";
}


            playbackProgress.textContent =
                (currentSoundIndex + 1) + " / " +
                temperatureHistory.length + " records played";

            soundProgress.max = temperatureHistory.length;
            soundProgress.value = currentSoundIndex + 1;

            playbackStatus.textContent = "EarthBeat is playing...";

            // Map temperature anomaly to sound pitch
            const frequency = Math.max(
                220,
                Math.min(660, 440 + data.value * 100)
            );

            oscillator = audioContext.createOscillator();
            gainNode = audioContext.createGain();

            oscillator.type = "sine";
            oscillator.frequency.value = frequency;

        

const noteDuration = playMode.value === "demo" ? 0.18 : 0.35;

gainNode.gain.setValueAtTime(
    0.08,
    audioContext.currentTime
);

gainNode.gain.setValueAtTime(
    0,
    audioContext.currentTime + noteDuration
);

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.start();
            oscillator.stop(audioContext.currentTime + noteDuration);

            currentSoundIndex++;

           

const playbackDelay = playMode.value === "demo" ? 250 : 500;

soundTimer = setTimeout(playNextNote, playbackDelay);
        }

        playNextNote();

    }).catch(error => {
        console.error("Audio error:", error);
    });
}

if (playBtn && stopBtn) {

    playBtn.addEventListener("click", () => {

    playEarthBeat();

    const climateVideo = document.getElementById("climateVideo");

    if (climateVideo) {
        climateVideo.muted = true;

        climateVideo.play().catch(error => {
            console.log("Video playback error:", error);
        });
    }

});

    stopBtn.addEventListener("click", () => {

    stopEarthBeat();

    const climateVideo = document.getElementById("climateVideo");

    if (climateVideo) {
        climateVideo.pause();
        climateVideo.currentTime = 0;
    }

});
const climateVideo = document.getElementById("climateVideo");

if (climateVideo) {
    climateVideo.addEventListener("ended", () => {
        stopEarthBeat();
    });
}

}